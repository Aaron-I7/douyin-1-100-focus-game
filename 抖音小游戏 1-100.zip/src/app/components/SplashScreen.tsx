import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { motion } from "motion/react";

export function SplashScreen() {
  const navigate = useNavigate();
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState("正在连接服务器...");

  useEffect(() => {
    const steps = [
      { p: 25, t: "正在加载资源..." },
      { p: 55, t: "正在初始化游戏..." },
      { p: 80, t: "正在准备数据..." },
      { p: 100, t: "加载完成！" },
    ];
    let i = 0;
    const timer = setInterval(() => {
      if (i < steps.length) {
        setProgress(steps[i].p);
        setStatusText(steps[i].t);
        i++;
      } else {
        clearInterval(timer);
        setTimeout(() => navigate("/home"), 400);
      }
    }, 600);
    return () => clearInterval(timer);
  }, [navigate]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-[#0f0c29] via-[#302b63] to-[#24243e] text-white relative overflow-hidden">
      {/* Decorative circles */}
      <div className="absolute w-64 h-64 rounded-full bg-purple-500/20 blur-3xl -top-20 -left-20" />
      <div className="absolute w-80 h-80 rounded-full bg-blue-500/15 blur-3xl -bottom-32 -right-20" />

      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, type: "spring" }}
        className="flex flex-col items-center z-10"
      >
        {/* Logo */}
        <div className="w-28 h-28 rounded-3xl bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 flex items-center justify-center shadow-2xl shadow-orange-500/40 mb-6">
          <span className="text-white" style={{ fontSize: "2.5rem", fontWeight: 800 }}>1-100</span>
        </div>

        <h1 className="text-white mb-2" style={{ fontSize: "1.8rem", fontWeight: 700 }}>舒尔特方格挑战</h1>
        <p className="text-white/60 mb-10" style={{ fontSize: "0.875rem" }}>训练你的注意力与反应速度</p>

        {/* Progress bar */}
        <div className="w-64 h-2 bg-white/10 rounded-full overflow-hidden mb-4">
          <motion.div
            className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full"
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.4 }}
          />
        </div>
        <p className="text-white/50" style={{ fontSize: "0.8rem" }}>{statusText}</p>
      </motion.div>
    </div>
  );
}
