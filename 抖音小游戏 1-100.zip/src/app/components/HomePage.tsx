import { useNavigate } from "react-router";
import { motion } from "motion/react";
import { gameStore } from "./gameStore";
import { Trophy, Users, Crown, ChevronRight } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const BG_URL = "https://images.unsplash.com/photo-1760144597301-ff821dbe28e6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMG5lb24lMjBnYW1lJTIwYmFja2dyb3VuZCUyMGRhcmt8ZW58MXx8fHwxNzczODIxNjYyfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

const MEDAL_COLORS = ["from-yellow-400 to-yellow-600", "from-gray-300 to-gray-500", "from-amber-600 to-amber-800"];

export function HomePage() {
  const navigate = useNavigate();

  const handleStart = () => {
    if (gameStore.freeCount <= 0) return;
    gameStore.useFree();
    navigate("/game");
  };

  return (
    <div className="min-h-screen relative overflow-hidden text-white">
      {/* BG */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback src={BG_URL} alt="bg" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/60" />
      </div>

      <div className="relative z-10 flex flex-col min-h-screen px-4 pt-14 pb-6 max-w-md mx-auto">
        {/* Top-right blackboard */}
        <motion.div
          initial={{ x: 100, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="self-end bg-[#2a2a2a] border-2 border-[#4a4a3a] rounded-xl p-3 mb-4 shadow-lg"
          style={{ minWidth: 160 }}
        >
          <div className="text-center mb-1" style={{ fontSize: "0.7rem", color: "#8B8B7A" }}>📋 挑战公告板</div>
          <div className="flex items-center gap-2 mb-1">
            <Users size={14} className="text-cyan-400" />
            <span style={{ fontSize: "0.75rem" }}>挑战人数</span>
            <span className="ml-auto text-cyan-400" style={{ fontSize: "0.85rem", fontWeight: 700 }}>{gameStore.totalChallengers.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-2">
            <Trophy size={14} className="text-yellow-400" />
            <span style={{ fontSize: "0.75rem" }}>今日通过</span>
            <span className="ml-auto text-yellow-400" style={{ fontSize: "0.85rem", fontWeight: 700 }}>{gameStore.passedToday.toLocaleString()}</span>
          </div>
        </motion.div>

        {/* Title */}
        <motion.div
          initial={{ y: -30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-center mb-6"
        >
          <h1 className="text-white" style={{ fontSize: "2.2rem", fontWeight: 800 }}>
            <span className="bg-gradient-to-r from-yellow-300 via-orange-400 to-red-400 bg-clip-text text-transparent">1-100</span>
          </h1>
          <p className="text-white/50" style={{ fontSize: "0.85rem" }}>舒尔特方格 · 极限注意力挑战</p>
        </motion.div>

        {/* Start button */}
        <motion.button
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.96 }}
          onClick={handleStart}
          className="w-full py-4 rounded-2xl bg-gradient-to-r from-orange-500 via-red-500 to-pink-500 shadow-xl shadow-red-500/30 mb-2 relative overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/10 rounded-2xl" />
          <span className="text-white relative z-10" style={{ fontSize: "1.3rem", fontWeight: 700 }}>🎮 开始游戏</span>
          <div className="text-white/80 relative z-10" style={{ fontSize: "0.75rem" }}>
            今日剩余免费次数: {gameStore.freeCount}
          </div>
        </motion.button>

        {/* Province ranking */}
        <div className="mt-5 flex-1">
          <div className="flex items-center gap-2 mb-3">
            <Crown size={18} className="text-yellow-400" />
            <span style={{ fontSize: "1rem", fontWeight: 700 }}>通关省份排行榜</span>
          </div>

          <div className="space-y-2">
            {gameStore.provinceData.map((item, idx) => (
              <motion.div
                key={item.province}
                initial={{ x: -40, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: idx * 0.06 }}
                className="flex items-center gap-3 bg-white/10 backdrop-blur-sm rounded-xl px-3 py-2"
              >
                {/* Rank badge */}
                {idx < 3 ? (
                  <div className={`w-7 h-7 rounded-full bg-gradient-to-br ${MEDAL_COLORS[idx]} flex items-center justify-center shadow-md`}>
                    <span style={{ fontSize: "0.75rem", fontWeight: 700 }}>{idx + 1}</span>
                  </div>
                ) : (
                  <div className="w-7 h-7 rounded-full bg-white/10 flex items-center justify-center">
                    <span style={{ fontSize: "0.75rem" }} className="text-white/60">{idx + 1}</span>
                  </div>
                )}

                <span style={{ fontSize: "0.9rem", fontWeight: 600, minWidth: 48 }}>{item.province}</span>

                {/* Avatars */}
                <div className="flex -space-x-2 flex-1">
                  {item.avatars.map((av, ai) => (
                    <div
                      key={ai}
                      className="w-7 h-7 rounded-full bg-gradient-to-br from-purple-400 to-blue-500 flex items-center justify-center border-2 border-[#1a1a2e] shadow"
                    >
                      <span style={{ fontSize: "0.8rem" }}>{av}</span>
                    </div>
                  ))}
                  {gameStore.userPassed && idx === 0 && (
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center border-2 border-[#1a1a2e] shadow ring-2 ring-yellow-400">
                      <span style={{ fontSize: "0.8rem" }}>🌟</span>
                    </div>
                  )}
                </div>

                <span className="text-white/50" style={{ fontSize: "0.75rem" }}>{item.count.toLocaleString()}人</span>
                <ChevronRight size={14} className="text-white/30" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
