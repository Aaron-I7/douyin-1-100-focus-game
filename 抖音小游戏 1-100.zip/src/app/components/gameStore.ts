// Simple global state for the game
let _freeCount = 3;
let _passedToday = 1892;
let _totalChallengers = 58423;
let _userPassed = false;
let _userAvatar = "";

const PROVINCE_DATA = [
  { province: "广东", count: 3421, avatars: ["🧑","👩","👨","🧒","👧"] },
  { province: "浙江", count: 2987, avatars: ["👩","👨","🧑","👧"] },
  { province: "江苏", count: 2654, avatars: ["👨","👩","🧒","🧑"] },
  { province: "北京", count: 2301, avatars: ["🧑","👧","👨"] },
  { province: "上海", count: 2198, avatars: ["👩","👨","🧑"] },
  { province: "四川", count: 1876, avatars: ["👨","🧒","👩"] },
  { province: "湖北", count: 1654, avatars: ["👩","🧑","👨"] },
  { province: "山东", count: 1543, avatars: ["👨","👧","🧑"] },
  { province: "福建", count: 1321, avatars: ["🧑","👩","👨"] },
  { province: "河南", count: 1198, avatars: ["👨","👩","🧒"] },
];

export const gameStore = {
  get freeCount() { return _freeCount; },
  useFree() { if (_freeCount > 0) _freeCount--; },
  get passedToday() { return _passedToday; },
  get totalChallengers() { return _totalChallengers; },
  get provinceData() { return PROVINCE_DATA; },
  get userPassed() { return _userPassed; },
  setUserPassed(v: boolean) { _userPassed = v; },
  get userAvatar() { return _userAvatar; },
  setUserAvatar(v: string) { _userAvatar = v; },
  incrementPassed() { _passedToday++; },
};
