import { useState, useEffect, useCallback, useRef } from "react";
import { useNavigate } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { X, Clock } from "lucide-react";
import { gameStore } from "./gameStore";
import confetti from "canvas-confetti";

// Generate shuffled array
function shuffle(n: number): number[] {
  const arr = Array.from({ length: n }, (_, i) => i + 1);
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

// Random clip-path for irregular shapes
function getClipPath(idx: number): string {
  const paths = [
    "polygon(5% 0%, 95% 3%, 100% 95%, 2% 100%)",
    "polygon(3% 2%, 98% 0%, 96% 98%, 0% 95%)",
    "polygon(0% 5%, 100% 0%, 97% 100%, 4% 96%)",
    "polygon(2% 0%, 96% 4%, 100% 97%, 0% 100%)",
    "polygon(4% 3%, 100% 0%, 98% 100%, 0% 98%)",
    "polygon(0% 0%, 97% 2%, 100% 100%, 3% 97%)",
    "polygon(1% 4%, 100% 0%, 96% 96%, 0% 100%)",
    "polygon(3% 0%, 100% 3%, 97% 100%, 0% 96%)",
    "polygon(0% 2%, 98% 0%, 100% 98%, 2% 100%)",
  ];
  return paths[idx % paths.length];
}

// Colors for blocks
const BLOCK_COLORS = [
  "from-violet-500 to-purple-700",
  "from-blue-500 to-indigo-700",
  "from-cyan-500 to-teal-700",
  "from-emerald-500 to-green-700",
  "from-yellow-500 to-amber-700",
  "from-orange-500 to-red-700",
  "from-pink-500 to-rose-700",
  "from-fuchsia-500 to-purple-700",
  "from-sky-500 to-blue-700",
];

type GamePhase = "level1" | "transition" | "level2" | "victory";

export function GamePage() {
  const navigate = useNavigate();
  const [phase, setPhase] = useState<GamePhase>("level1");
  const [numbers, setNumbers] = useState<number[]>(() => shuffle(9));
  const [nextExpected, setNextExpected] = useState(1);
  const [clickedSet, setClickedSet] = useState<Set<number>>(new Set());
  const [wrongId, setWrongId] = useState<number | null>(null);
  const [pressedId, setPressedId] = useState<number | null>(null);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes in seconds
  const [showVictoryModal, setShowVictoryModal] = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Timer for level 2
  useEffect(() => {
    if (phase === "level2") {
      timerRef.current = setInterval(() => {
        setTimeLeft((t) => {
          if (t <= 1) {
            clearInterval(timerRef.current!);
            // Time's up - go back
            navigate("/home");
            return 0;
          }
          return t - 1;
        });
      }, 1000);
      return () => { if (timerRef.current) clearInterval(timerRef.current); };
    }
  }, [phase, navigate]);

  const handleClick = useCallback((num: number) => {
    setPressedId(num);
    setTimeout(() => setPressedId(null), 150);

    if (num === nextExpected) {
      const newClicked = new Set(clickedSet);
      newClicked.add(num);
      setClickedSet(newClicked);
      const next = nextExpected + 1;
      setNextExpected(next);

      const maxNum = phase === "level1" ? 9 : 100;
      if (next > maxNum) {
        if (phase === "level1") {
          // Transition to level 2
          setPhase("transition");
          setTimeout(() => {
            setNumbers(shuffle(100));
            setNextExpected(1);
            setClickedSet(new Set());
            setTimeLeft(600);
            setPhase("level2");
          }, 2500);
        } else {
          // Victory!
          if (timerRef.current) clearInterval(timerRef.current);
          setPhase("victory");
          gameStore.setUserPassed(true);
          gameStore.incrementPassed();
          confetti({ particleCount: 200, spread: 100, origin: { y: 0.6 } });
          setTimeout(() => setShowVictoryModal(true), 500);
        }
      }
    } else {
      setWrongId(num);
      setTimeout(() => setWrongId(null), 500);
    }
  }, [nextExpected, clickedSet, phase]);

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
  };

  const maxNum = phase === "level1" ? 9 : 100;
  const gridCols = phase === "level1" ? 3 : 10;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f0c29] via-[#302b63] to-[#24243e] text-white flex flex-col relative overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-14 pb-2">
        <button onClick={() => navigate("/home")} className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center">
          <X size={20} />
        </button>
        <div className="text-center">
          <span className="text-white/60" style={{ fontSize: "0.75rem" }}>
            {phase === "level1" ? "第一关 · 热身" : phase === "level2" ? "最终关 · 1-100" : ""}
          </span>
        </div>
        <div className="w-10" />
      </div>

      {/* Timer - only show in level 2 */}
      {phase === "level2" && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-center gap-2 mb-2"
        >
          <Clock size={16} className={timeLeft < 60 ? "text-red-400" : "text-cyan-400"} />
          <span
            style={{ fontSize: "1.5rem", fontWeight: 700, fontFamily: "monospace" }}
            className={timeLeft < 60 ? "text-red-400" : "text-cyan-400"}
          >
            {formatTime(timeLeft)}
          </span>
        </motion.div>
      )}

      {/* Progress hint */}
      {(phase === "level1" || phase === "level2") && (
        <div className="text-center mb-3">
          <span className="text-white/40" style={{ fontSize: "0.75rem" }}>
            请按顺序点击: <span className="text-yellow-400" style={{ fontWeight: 700, fontSize: "1rem" }}>{nextExpected}</span> / {maxNum}
          </span>
        </div>
      )}

      {/* Game grid */}
      {(phase === "level1" || phase === "level2") && (
        <div className="flex-1 flex items-center justify-center px-3">
          <div
            className="grid gap-1.5 w-full"
            style={{
              gridTemplateColumns: `repeat(${gridCols}, 1fr)`,
              maxWidth: phase === "level1" ? 320 : "100%",
            }}
          >
            {numbers.map((num, idx) => {
              const isClicked = clickedSet.has(num);
              const isWrong = wrongId === num;
              const isPressed = pressedId === num;

              return (
                <motion.button
                  key={`${phase}-${num}`}
                  onClick={() => !isClicked && handleClick(num)}
                  disabled={isClicked}
                  animate={{
                    scale: isPressed ? 0.88 : 1,
                    y: isPressed ? 4 : 0,
                  }}
                  transition={{ type: "spring", stiffness: 500, damping: 20 }}
                  className={`
                    relative rounded-lg flex items-center justify-center select-none
                    transition-all duration-100
                    ${isClicked
                      ? "bg-white/5 border border-white/10"
                      : isWrong
                        ? "bg-red-500/80 border-2 border-red-300"
                        : `bg-gradient-to-br ${BLOCK_COLORS[idx % BLOCK_COLORS.length]} border border-white/20 shadow-lg`
                    }
                  `}
                  style={{
                    aspectRatio: "1",
                    clipPath: phase === "level1" ? getClipPath(idx) : undefined,
                    minHeight: phase === "level1" ? 80 : undefined,
                    boxShadow: !isClicked && !isWrong
                      ? "0 4px 0 rgba(0,0,0,0.4), 0 6px 12px rgba(0,0,0,0.3)"
                      : isPressed
                        ? "0 1px 0 rgba(0,0,0,0.4)"
                        : undefined,
                  }}
                >
                  {isWrong && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1.2, rotate: [0, -10, 10, 0] }}
                      className="absolute inset-0 flex items-center justify-center"
                    >
                      <span style={{ fontSize: phase === "level1" ? "1.5rem" : "0.7rem" }}>❌</span>
                    </motion.div>
                  )}
                  {!isWrong && (
                    <span
                      style={{
                        fontSize: phase === "level1" ? "1.8rem" : "0.7rem",
                        fontWeight: 800,
                        textShadow: "0 2px 4px rgba(0,0,0,0.5)",
                      }}
                      className={isClicked ? "text-white/20" : "text-white"}
                    >
                      {isClicked ? "✓" : num}
                    </span>
                  )}
                </motion.button>
              );
            })}
          </div>
        </div>
      )}

      {/* Transition overlay */}
      <AnimatePresence>
        {phase === "transition" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-black/80"
          >
            <motion.div
              initial={{ scale: 0.3, opacity: 0, rotate: -10 }}
              animate={{ scale: 1, opacity: 1, rotate: 0 }}
              transition={{ type: "spring", stiffness: 200 }}
              className="text-center"
            >
              <div
                className="bg-gradient-to-r from-yellow-300 via-orange-400 to-red-400 bg-clip-text text-transparent"
                style={{ fontSize: "3rem", fontWeight: 900 }}
              >
                最后一关！
              </div>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="text-white/60 mt-4"
                style={{ fontSize: "1rem" }}
              >
                1 → 100 · 限时10分钟
              </motion.p>
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1.2 }}
                className="text-white/30 mt-6"
                style={{ fontSize: "0.8rem" }}
              >
                准备中...
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Victory modal */}
      <AnimatePresence>
        {showVictoryModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="absolute inset-0 z-50 flex items-center justify-center bg-black/70"
          >
            <motion.div
              initial={{ scale: 0.5, y: 50 }}
              animate={{ scale: 1, y: 0 }}
              transition={{ type: "spring", stiffness: 200 }}
              className="bg-gradient-to-br from-[#1a1a3e] to-[#2d2d5e] rounded-3xl p-8 mx-6 text-center border border-white/10 shadow-2xl"
            >
              <div style={{ fontSize: "4rem" }} className="mb-2">🏆</div>
              <h2
                className="bg-gradient-to-r from-yellow-300 to-orange-400 bg-clip-text text-transparent mb-2"
                style={{ fontSize: "1.6rem", fontWeight: 800 }}
              >
                恭喜通关！
              </h2>
              <p className="text-white/50 mb-6" style={{ fontSize: "0.85rem" }}>
                你已成功完成 1-100 舒尔特方格挑战！
                <br />用时 {formatTime(600 - timeLeft)}
              </p>
              <div className="flex items-center justify-center gap-2 mb-6">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center border-2 border-yellow-400 shadow-lg">
                  <span style={{ fontSize: "1.5rem" }}>🌟</span>
                </div>
                <span className="text-white/60" style={{ fontSize: "0.8rem" }}>你的头像已加入通关榜</span>
              </div>
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate("/home")}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-orange-500 to-red-500 shadow-lg"
              >
                <span className="text-white" style={{ fontSize: "1rem", fontWeight: 700 }}>返回首页</span>
              </motion.button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
