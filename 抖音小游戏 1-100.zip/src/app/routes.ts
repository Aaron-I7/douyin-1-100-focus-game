import { createBrowserRouter } from "react-router";
import { SplashScreen } from "./components/SplashScreen";
import { HomePage } from "./components/HomePage";
import { GamePage } from "./components/GamePage";

export const router = createBrowserRouter([
  { path: "/", Component: SplashScreen },
  { path: "/home", Component: HomePage },
  { path: "/game", Component: GamePage },
]);
