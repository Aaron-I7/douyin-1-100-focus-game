
  # 抖音小游戏 1-100

  This is a code bundle for 抖音小游戏 1-100. The original project is available at https://www.figma.com/design/28Ii3FaVqHjGXt614GcVu0/%E6%8A%96%E9%9F%B3%E5%B0%8F%E6%B8%B8%E6%88%8F-1-100.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  